import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AppointmentGUI extends JPanel {
    public AppointmentGUI() {
        setLayout(null);


        JLabel lblAppointmentID = new JLabel("Appointment ID:");
        lblAppointmentID.setBounds(50, 50, 150, 30);
        add(lblAppointmentID);

        JTextField txtAppointmentID = new JTextField();
        txtAppointmentID.setBounds(200, 50, 300, 30);
        add(txtAppointmentID);


        JLabel lblPatientID = new JLabel("Patient ID:");
        lblPatientID.setBounds(50, 100, 150, 30);
        add(lblPatientID);

        JTextField txtPatientID = new JTextField();
        txtPatientID.setBounds(200, 100, 300, 30);
        add(txtPatientID);


        JLabel lblDoctorID = new JLabel("Doctor ID:");
        lblDoctorID.setBounds(50, 150, 150, 30);
        add(lblDoctorID);

        JTextField txtDoctorID = new JTextField();
        txtDoctorID.setBounds(200, 150, 300, 30);
        add(txtDoctorID);


        JLabel lblDate = new JLabel("Date (YYYY-MM-DD):");
        lblDate.setBounds(50, 200, 150, 30);
        add(lblDate);

        JTextField txtDate = new JTextField();
        txtDate.setBounds(200, 200, 300, 30);
        add(txtDate);


        JLabel lblTime = new JLabel("Time (HH:MM):");
        lblTime.setBounds(50, 250, 150, 30);
        add(lblTime);

        JTextField txtTime = new JTextField();
        txtTime.setBounds(200, 250, 300, 30);
        add(txtTime);


        JButton btnSave = new JButton("Save Appointment");
        btnSave.setBounds(50, 320, 450, 40);
        btnSave.setBackground(new Color(0, 200, 100));
        btnSave.setForeground(Color.WHITE);

        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String appointmentID = txtAppointmentID.getText();
                String patientID = txtPatientID.getText();
                String doctorID = txtDoctorID.getText();
                String date = txtDate.getText();
                String time = txtTime.getText();

                if (appointmentID.isEmpty() || patientID.isEmpty() || doctorID.isEmpty() || date.isEmpty() || time.isEmpty()) {
                    JOptionPane.showMessageDialog(AppointmentGUI.this, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try (Connection connection = DatabaseConfig.getConnection();
                     PreparedStatement preparedStatement = connection.prepareStatement(
                             "INSERT INTO Appointments (appointmentID, patientID, doctorID, Date, Time) VALUES (?, ?, ?, ?, ?)")) {

                    preparedStatement.setString(1, appointmentID);
                    preparedStatement.setString(2, patientID);
                    preparedStatement.setString(3, doctorID);
                    preparedStatement.setString(4, date);
                    preparedStatement.setString(5, time);

                    preparedStatement.executeUpdate();
                    JOptionPane.showMessageDialog(AppointmentGUI.this, "Appointment saved successfully!");


                    txtAppointmentID.setText("");
                    txtPatientID.setText("");
                    txtDoctorID.setText("");
                    txtDate.setText("");
                    txtTime.setText("");

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(AppointmentGUI.this, "Either you are trying to access a doctor or patient id that is not registered or you are using appointment ID which is already used " );
                    ex.printStackTrace();
                }
            }
        });
        add(btnSave);
    }
}