import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class ReceptionistGUI extends JPanel {
    private JTextField idField, nameField, shiftField, contactField, departmentField;
    private JComboBox<String> availabilityComboBox;

    public ReceptionistGUI() {
        setLayout(new BorderLayout());

        JPanel formPanel = createFormPanel();
        JPanel buttonPanel = createButtonPanel();

        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        idField = new JTextField();
        nameField = new JTextField();
        shiftField = new JTextField();
        contactField = new JTextField();
        departmentField = new JTextField();
        availabilityComboBox = new JComboBox<>(new String[]{"AVAILABLE", "UNAVAILABLE"});

        formPanel.add(new JLabel("Receptionist ID:"));
        formPanel.add(idField);
        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("shiftTime:"));
        formPanel.add(shiftField);
        formPanel.add(new JLabel("Contact Number:"));
        formPanel.add(contactField);
        formPanel.add(new JLabel("Assigned Department:"));
        formPanel.add(departmentField);
        formPanel.add(new JLabel("Availability Status:"));
        formPanel.add(availabilityComboBox);

        return formPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));

        JButton saveButton = new JButton("Save");
        JButton updateButton = new JButton("Update");
        JButton retrieveButton = new JButton("Retrieve");

        saveButton.addActionListener(e -> saveReceptionistInfo());
        updateButton.addActionListener(e -> updateReceptionistInfo());
        retrieveButton.addActionListener(e -> retrieveReceptionistInfo());

        buttonPanel.add(saveButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(retrieveButton);

        return buttonPanel;
    }

    private void saveReceptionistInfo() {
        String query = "INSERT INTO Receptionists (receptionistID, name, shiftTime, contactNumber, assignedDepartment, availability) VALUES (?, ?, ?, ?, ?, ?)";
        executeDatabaseOperation(query, true);
    }

    private void updateReceptionistInfo() {
        String query = "UPDATE Receptionists SET name=?, shiftTime=?, contactNumber=?, assignedDepartment=?, availability=? WHERE receptionistID=?";
        executeDatabaseOperation(query, false);
    }

    private void retrieveReceptionistInfo() {
        String id = idField.getText();
        String query = "SELECT * FROM Receptionists WHERE receptionistID=?";

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                nameField.setText(rs.getString("name"));
                shiftField.setText(rs.getString("shiftTime"));
                contactField.setText(rs.getString("contactNumber"));
                departmentField.setText(rs.getString("assignedDepartment"));
                availabilityComboBox.setSelectedItem(rs.getString("availability"));
            } else {
                JOptionPane.showMessageDialog(this, "No receptionist found with ID: " + id);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error retrieving receptionist information: " + ex.getMessage());
        }
    }
    private void executeDatabaseOperation(String query, boolean isInsert) {
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(isInsert ? 1 : 6, idField.getText());
            stmt.setString(2, nameField.getText());
            stmt.setString(3, shiftField.getText());
            stmt.setString(4, contactField.getText());
            stmt.setString(5, departmentField.getText());
            if (isInsert) {
                stmt.setString(6, (String) availabilityComboBox.getSelectedItem());
            }

            int rowsAffected = stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, rowsAffected > 0 ?
                    (isInsert ? "Receptionist information saved successfully!" : "Receptionist information updated successfully!") :
                    "Failed to process receptionist information.");
            clearFields();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        shiftField.setText("");
        contactField.setText("");
        departmentField.setText("");
        availabilityComboBox.setSelectedItem("AVAILABLE");
    }
   public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ReceptionistGUI().setVisible(true));
   }
}













