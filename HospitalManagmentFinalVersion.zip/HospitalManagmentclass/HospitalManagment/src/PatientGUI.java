import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class PatientGUI extends JPanel {
    private JTextField patientIdField, nameField, ageField, statusPatientIdField;
    private JComboBox<String> genderComboBox;
    private JTextArea medicalHistoryField;
    private JButton saveButton, checkStatusButton;

    public PatientGUI() {
        setLayout(new BorderLayout());

        JPanel formPanel = createFormPanel();
        JPanel buttonPanel = createButtonPanel();

        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblPatientId = new JLabel("Patient ID:");
        patientIdField = new JTextField();
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(lblPatientId, gbc);
        gbc.gridx = 1; gbc.gridy = 0;
        formPanel.add(patientIdField, gbc);

        JLabel lblName = new JLabel("Name:");
        nameField = new JTextField();
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(lblName, gbc);
        gbc.gridx = 1; gbc.gridy = 1;
        formPanel.add(nameField, gbc);

        JLabel lblAge = new JLabel("Age:");
        ageField = new JTextField();
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(lblAge, gbc);
        gbc.gridx = 1; gbc.gridy = 2;
        formPanel.add(ageField, gbc);

        JLabel lblGender = new JLabel("Gender:");
        genderComboBox = new JComboBox<>(new String[]{"Male", "Female"});
        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(lblGender, gbc);
        gbc.gridx = 1; gbc.gridy = 3;
        formPanel.add(genderComboBox, gbc);

        JLabel lblMedicalHistory = new JLabel("Medical History:");
        medicalHistoryField = new JTextArea(5, 20);
        medicalHistoryField.setLineWrap(true);
        medicalHistoryField.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(medicalHistoryField);
        gbc.gridx = 0; gbc.gridy = 4;
        formPanel.add(lblMedicalHistory, gbc);
        gbc.gridx = 1; gbc.gridy = 4;
        formPanel.add(scrollPane, gbc);

        return formPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout());

        saveButton = new JButton("Save Patient Info");
        saveButton.setBackground(new Color(0, 150, 200));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFont(new Font("Arial", Font.BOLD, 14));
        saveButton.addActionListener(e -> savePatientInfo());
        buttonPanel.add(saveButton);

        JLabel lblStatus = new JLabel("Check Status by Patient ID:");
        buttonPanel.add(lblStatus);

        statusPatientIdField = new JTextField(10);
        buttonPanel.add(statusPatientIdField);

        checkStatusButton = new JButton("Check Status");
        checkStatusButton.setBackground(new Color(0, 150, 200));
        checkStatusButton.setForeground(Color.WHITE);
        checkStatusButton.setFont(new Font("Arial", Font.BOLD, 12));
        checkStatusButton.addActionListener(e -> checkPatientStatus());
        buttonPanel.add(checkStatusButton);

        return buttonPanel;
    }

    private void savePatientInfo() {
        String patientId = patientIdField.getText();
        String name = nameField.getText();

        int age;
        try {
            age = Integer.parseInt(ageField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid age.");
            return;
        }

        String gender = (String) genderComboBox.getSelectedItem();
        String medicalHistory = medicalHistoryField.getText();

        String query = "INSERT INTO Patientinformation (patientId, name, age, gender, medicalHistory) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, patientId);
            stmt.setString(2, name);
            stmt.setInt(3, age);
            stmt.setString(4, gender);
            stmt.setString(5, medicalHistory);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Patient information saved successfully!");
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to save patient information.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error saving patient information:The patient id does not exist or the data type you insert on age field is not correct " );
        }
    }

    private void checkPatientStatus() {
        String patientId = statusPatientIdField.getText().trim();

        if (patientId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Patient ID.");
            return;
        }

        String query = "SELECT prescriptionDetails, treatmentSchedule FROM DoctorPrescriptions WHERE patientID = ?";

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, patientId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String prescription = rs.getString("prescriptionDetails");
                    String schedule = rs.getString("treatmentSchedule");

                    JOptionPane.showMessageDialog(this,
                            "Prescription:\n" + prescription + "\n\nSchedule:\n" + schedule,
                            "Patient Status",
                            JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Status: Pending", "Patient Status", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error checking status: " + ex.getMessage());
        }
    }

    private void clearFields() {
        patientIdField.setText("");
        nameField.setText("");
        ageField.setText("");
        genderComboBox.setSelectedIndex(0); // Reset to "Male"
        medicalHistoryField.setText("");
    }
}
