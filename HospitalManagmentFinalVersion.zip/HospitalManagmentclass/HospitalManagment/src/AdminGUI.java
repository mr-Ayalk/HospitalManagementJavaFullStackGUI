import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AdminGUI extends JPanel {

    public AdminGUI() {

        setLayout(null);


        JLabel lblRole = new JLabel("Role:");
        lblRole.setBounds(50, 50, 100, 30);
        add(lblRole);

        JComboBox<String> cmbRole = new JComboBox<>(new String[]{"Doctor", "Receptionist", "Pharmacist"});
        cmbRole.setBounds(150, 50, 300, 30);
        add(cmbRole);

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setBounds(50, 100, 100, 30);
        add(lblUsername);

        JTextField txtUsername = new JTextField();
        txtUsername.setBounds(150, 100, 300, 30);
        add(txtUsername);


        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setBounds(50, 150, 100, 30);
        add(lblPassword);

        JTextField txtPassword = new JTextField();
        txtPassword.setBounds(150, 150, 300, 30);
        add(txtPassword);


        JButton btnAddStaff = new JButton("Add Staff");
        btnAddStaff.setBounds(50, 200, 200, 40);
        btnAddStaff.setBackground(new Color(100, 150, 255));
        btnAddStaff.setForeground(Color.WHITE);
        add(btnAddStaff);

        JButton btnRemoveStaff = new JButton("Remove Staff");
        btnRemoveStaff.setBounds(300, 200, 200, 40);
        btnRemoveStaff.setBackground(new Color(255, 100, 100));
        btnRemoveStaff.setForeground(Color.WHITE);
        add(btnRemoveStaff);


        JLabel lblPatientID = new JLabel("Enter Patient ID:");
        lblPatientID.setBounds(50, 260, 150, 30);
        add(lblPatientID);

        JTextField txtPatientID = new JTextField();
        txtPatientID.setBounds(150, 260, 300, 30);
        add(txtPatientID);

        JButton btnViewPatient = new JButton("View Patient Info");
        btnViewPatient.setBounds(50, 320, 450, 40);
        btnViewPatient.setBackground(new Color(0, 200, 100));
        btnViewPatient.setForeground(Color.WHITE);
        add(btnViewPatient);


        btnAddStaff.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String role = (String) cmbRole.getSelectedItem();
                String username = txtUsername.getText().trim();
                String password = txtPassword.getText().trim();

                if (!username.isEmpty() && !password.isEmpty()) {
                    try (Connection conn = DatabaseConfig.getConnection()) {
                        String sql;
                        PreparedStatement pstmt;

                        if ("Doctor".equalsIgnoreCase(role)) {
                            sql = "INSERT INTO Doctors (name, password) VALUES (?, ?)";
                            pstmt = conn.prepareStatement(sql);
                        } else if ("Receptionist".equalsIgnoreCase(role)) {
                            sql = "INSERT INTO recertionistdata (name, password) VALUES (?, ?)";
                            pstmt = conn.prepareStatement(sql);
                        } else if ("Pharmacist".equalsIgnoreCase(role)) {
                            sql = "INSERT INTO pharmacist (username, password) VALUES (?, ?)";
                            pstmt = conn.prepareStatement(sql);
                        } else {
                            throw new IllegalArgumentException("Invalid role: " + role);
                        }


                        pstmt.setString(1, username);
                        pstmt.setString(2, password);
                        pstmt.executeUpdate();
                        JOptionPane.showMessageDialog(AdminGUI.this, "Staff added successfully.");
                        txtUsername.setText("");
                        txtPassword.setText("");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(AdminGUI.this, "Error: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(AdminGUI.this, "Please fill in all fields.");
                }
            }
        });

        btnRemoveStaff.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String role = (String) cmbRole.getSelectedItem();
                String username = txtUsername.getText().trim();

                if (!username.isEmpty()) {
                    try (Connection conn = DatabaseConfig.getConnection()) {
                        String sql;
                        PreparedStatement pstmt;

                        if ("Doctor".equalsIgnoreCase(role)) {
                            sql = "DELETE FROM Doctors WHERE name = ?";
                        } else {
                            sql = "DELETE FROM recertionistdata WHERE name = ?";
                        }

                        pstmt = conn.prepareStatement(sql);
                        pstmt.setString(1, username);
                        int rowsAffected = pstmt.executeUpdate();

                        if (rowsAffected > 0) {
                            JOptionPane.showMessageDialog(AdminGUI.this, "Staff removed successfully.");
                        } else {
                            JOptionPane.showMessageDialog(AdminGUI.this, "No matching staff found.");
                        }

                        txtUsername.setText("");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(AdminGUI.this, "Error: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(AdminGUI.this, "Please enter a Username.");
                }
            }
        });

        btnViewPatient.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String patientID = txtPatientID.getText().trim();

                if (!patientID.isEmpty()) {
                    try (Connection conn = DatabaseConfig.getConnection()) {
                        String sql = "SELECT p.name, p.age, p.gender, p.medicalHistory, r.roomType, r.availability, b.totalAmount " +
                                "FROM patientinformation p " +
                                "LEFT JOIN Rooms r ON p.patientID = r.patientID " +
                                "LEFT JOIN Billing b ON p.patientID = b.patientId " +
                                "WHERE p.patientID = ?";

                        PreparedStatement pstmt = conn.prepareStatement(sql);
                        pstmt.setInt(1, Integer.parseInt(patientID));
                        ResultSet rs = pstmt.executeQuery();

                        if (rs.next()) {
                            String info = "Name: " + rs.getString("name") + "\n" +
                                    "Age: " + rs.getInt("age") + "\n" +
                                    "Gender: " + rs.getString("gender") + "\n" +
                                    "Medical History: " + rs.getString("medicalHistory") + "\n" +
                                    "Room Type: " + rs.getString("roomType") + "\n" +
                                    "Room Availability: " + rs.getBoolean("availability") + "\n" +
                                    "Total Bill Amount: " + rs.getBigDecimal("totalAmount");
                            JOptionPane.showMessageDialog(AdminGUI.this, info);
                        } else {
                            JOptionPane.showMessageDialog(AdminGUI.this, "Patient not found.");
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(AdminGUI.this, "Error: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(AdminGUI.this, "Please enter a Patient ID.");
                }
            }
        });
    }
}