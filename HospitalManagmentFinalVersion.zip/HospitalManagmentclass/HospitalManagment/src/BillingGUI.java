//import javax.swing.*;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class BillingGUI extends JPanel {
    public BillingGUI() {
        setLayout(null);


        JLabel lblBillId = new JLabel("Bill ID:");
        lblBillId.setBounds(50, 50, 150, 30);
        add(lblBillId);

        JTextField txtBillId = new JTextField();
        txtBillId.setBounds(200, 50, 300, 30);
        add(txtBillId);

        JLabel lblPatientId = new JLabel("Patient ID:");
        lblPatientId.setBounds(50, 100, 150, 30);
        add(lblPatientId);

        JTextField txtPatientId = new JTextField();
        txtPatientId.setBounds(200, 100, 300, 30);
        add(txtPatientId);

        JLabel lblDoctorFee = new JLabel("Doctor Fee:");
        lblDoctorFee.setBounds(50, 150, 150, 30);
        add(lblDoctorFee);

        JTextField txtDoctorFee = new JTextField();
        txtDoctorFee.setBounds(200, 150, 300, 30);
        add(txtDoctorFee);

        JLabel lblRoomFee = new JLabel("Room Fee:");
        lblRoomFee.setBounds(50, 200, 150, 30);
        add(lblRoomFee);

        JTextField txtRoomFee = new JTextField();
        txtRoomFee.setBounds(200, 200, 300, 30);
        add(txtRoomFee);

        JLabel lblAdditionalCharges = new JLabel("Additional Charges:");
        lblAdditionalCharges.setBounds(50, 250, 150, 30);
        add(lblAdditionalCharges);

        JTextField txtAdditionalCharges = new JTextField();
        txtAdditionalCharges.setBounds(200, 250, 300, 30);
        add(txtAdditionalCharges);

        JLabel lblTotalAmount = new JLabel("Total Amount:");
        lblTotalAmount.setBounds(50, 300, 150, 30);
        add(lblTotalAmount);

        JLabel lblTotalValue = new JLabel("$0.00");
        lblTotalValue.setBounds(200, 300, 300, 30);
        lblTotalValue.setForeground(Color.BLUE);
        add(lblTotalValue);


        JButton btnGenerateBill = new JButton("Generate Bill");
        btnGenerateBill.setBounds(50, 360, 200, 40);
        btnGenerateBill.setBackground(new Color(0, 150, 200));
        btnGenerateBill.setForeground(Color.WHITE);
        add(btnGenerateBill);

        JButton btnSaveBill = new JButton("Save Bill");
        btnSaveBill.setBounds(300, 360, 200, 40);
        btnSaveBill.setBackground(new Color(0, 200, 100));
        btnSaveBill.setForeground(Color.WHITE);
        add(btnSaveBill);

        JButton btnGenerateReport = new JButton("Generate Report");
        btnGenerateReport.setBounds(550, 360, 200, 40);
        btnGenerateReport.setBackground(new Color(200, 150, 0));
        btnGenerateReport.setForeground(Color.WHITE);
        add(btnGenerateReport);


        JTextArea reportArea = new JTextArea();
        reportArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(reportArea);
        scrollPane.setBounds(50, 420, 700, 100);
        add(scrollPane);

        btnGenerateBill.addActionListener(e -> {
            try {
                double doctorFee = Double.parseDouble(txtDoctorFee.getText());
                double roomFee = Double.parseDouble(txtRoomFee.getText());
                double additionalCharges = Double.parseDouble(txtAdditionalCharges.getText());
                double totalAmount = doctorFee + roomFee + additionalCharges;
                lblTotalValue.setText("$" + totalAmount);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(BillingGUI.this, "Invalid input. Please enter valid numbers.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnSaveBill.addActionListener(e -> {
            String billId = txtBillId.getText();
            String patientId = txtPatientId.getText();
            try {
                double doctorFee = Double.parseDouble(txtDoctorFee.getText());
                double roomFee = Double.parseDouble(txtRoomFee.getText());
                double additionalCharges = Double.parseDouble(txtAdditionalCharges.getText());
                double totalAmount = doctorFee + roomFee + additionalCharges;

                String query = "INSERT INTO Billing (billId, patientId, doctorFee, roomFee, additionalCharges, totalAmount) VALUES (?, ?, ?, ?, ?, ?)";
                try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management", "root", "ayalk1995");
                     PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setString(1, billId);
                    stmt.setString(2, patientId);
                    stmt.setDouble(3, doctorFee);
                    stmt.setDouble(4, roomFee);
                    stmt.setDouble(5, additionalCharges);
                    stmt.setDouble(6, totalAmount);

                    int rowsAffected = stmt.executeUpdate();
                    JOptionPane.showMessageDialog(BillingGUI.this, rowsAffected > 0 ? "Bill saved successfully!" : "Failed to save bill.");
                }


                txtBillId.setText("");
                txtPatientId.setText("");
                txtDoctorFee.setText("");
                txtRoomFee.setText("");
                txtAdditionalCharges.setText("");
                lblTotalValue.setText("$0.00");

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(BillingGUI.this, "Invalid input. Please enter valid numbers.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(BillingGUI.this, "Either the Bill id is already used or you are trying to use available patient id");
            }
        });

        btnGenerateReport.addActionListener(e -> {
            String query = "SELECT * FROM Billing";
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management", "root", "ayalk1995");
                 PreparedStatement stmt = conn.prepareStatement(query)) {
                ResultSet rs = stmt.executeQuery();
                StringBuilder report = new StringBuilder("Billing Report:\n");
                report.append("-----------------------------------------------------------\n");
                report.append("Bill ID | Patient ID | Doctor Fee | Room Fee | Total Amount\n");
                report.append("-----------------------------------------------------------\n");

                while (rs.next()) {
                    report.append(rs.getString("billId")).append(" | ");
                    report.append(rs.getString("patientId")).append(" | ");
                    report.append("$").append(rs.getDouble("doctorFee")).append(" | ");
                    report.append("$").append(rs.getDouble("roomFee")).append(" | ");
                    report.append("$").append(rs.getDouble("totalAmount")).append("\n");
                }
                reportArea.setText(report.toString());
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(BillingGUI.this, "Error generating report: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}