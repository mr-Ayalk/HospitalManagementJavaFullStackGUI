import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

class DatabaseConfig {
    private static final String URL = "jdbc:mysql://localhost:3306/hospital_management3d";
    private static final String USER = "root";
    private static final String PASSWORD = "ayalk1995";

    // Get connection instance
    public static Connection getConnection() throws SQLException {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found. Include it in your library path.");
            e.printStackTrace();
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // Test connection
    public static void main(String[] args) {
        try (Connection connection = getConnection()) {
            System.out.println("Database connection successful!");
        } catch (SQLException e) {
            System.err.println("Database connection failed!");
            e.printStackTrace();
        }
    }
}

