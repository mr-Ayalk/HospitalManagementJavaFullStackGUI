import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class HomePage extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private String userRole;
    public HomePage(String username, String role) {
        this.userRole = role;

        setTitle("AAIT Hospital Management System - Home Page");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Navigation bar at the top
        JPanel navBar = new JPanel();
        navBar.setLayout(new GridLayout(1, 9)); // 9 menus in a single row
        navBar.setBackground(new Color(100, 150, 255));

        // Create the main panel with CardLayout
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // Dynamically add GUI panels to the main panel
        addGUIPanels();

        // Navigation buttons
        String[] menus = {
                "Admin", "Appointment", "Billing", "Pharmacy",
                "Room Management", "Medical Record", "Receptionist",
                "Doctor Prescription", "Patient"
        };

        Map<String, Boolean> accessPermissions = getAccessPermissions(role);

        for (String menu : menus) {
            JButton menuButton = new JButton(menu);
            menuButton.setBackground(Color.WHITE);
            menuButton.setForeground(Color.BLACK);
            menuButton.setFont(new Font("Arial", Font.BOLD, 14));
            navBar.add(menuButton);

            // Add action listener to switch panels or show "Access Denied"
            menuButton.addActionListener(e -> {
                if (accessPermissions.getOrDefault(menu, false)) {
                    cardLayout.show(mainPanel, menu);
                } else {
                    JOptionPane.showMessageDialog(this, "Access Denied!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            });
        }

        add(navBar, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);


        switch (role) {
            case "Doctor":
                cardLayout.show(mainPanel, "Doctor Prescription");
                break;
            case "Receptionist":
                cardLayout.show(mainPanel, "Receptionist");
                break;
            case "Pharmacist":
                cardLayout.show(mainPanel, "Pharmacy");
                break;
            case "Patient":
                cardLayout.show(mainPanel, "Patient");
                break;
            default:
                cardLayout.show(mainPanel, "Admin"); // Default to Admin page for other roles
                break;
        }
    }

    private void addGUIPanels() {
        // Add each GUI panel to the CardLayout
        mainPanel.add(new AdminGUI(), "Admin");
        mainPanel.add(new AppointmentGUI(), "Appointment");
        mainPanel.add(new BillingGUI(), "Billing");
        mainPanel.add(new PharmacyGUI(), "Pharmacy");
        mainPanel.add(new RoomManagementGUI(), "Room Management");
        mainPanel.add(new MedicalRecordGUI(), "Medical Record");
        mainPanel.add(new ReceptionistGUI(), "Receptionist");
        mainPanel.add(new DoctorPrescriptionGUI(), "Doctor Prescription");
        mainPanel.add(new PatientGUI(), "Patient");
    }

    private Map<String, Boolean> getAccessPermissions(String role) {
        Map<String, Boolean> permissions = new HashMap<>();


        String[] menus = {
                "Admin", "Appointment", "Billing", "Pharmacy",
                "Room Management", "Medical Record", "Receptionist",
                "Doctor Prescription", "Patient"
        };
        for (String menu : menus) {
            permissions.put(menu, false);
        }


        switch (role) {
            case "Admin":
                for (String menu : menus) {
                    permissions.put(menu, true);
                }
                break;
            case "Receptionist":
                permissions.put("Appointment", true);
                permissions.put("Billing", true);
                permissions.put("Room Management", true);
                permissions.put("Medical Record", true);
                permissions.put("Receptionist", true);
                break;
            case "Doctor":
                permissions.put("Doctor Prescription", true);
                permissions.put("Medical Record", true);
                break;
            case "Pharmacist":
                permissions.put("Pharmacy", true);
                break;
            case "Patient":
                permissions.put("Patient", true);
                break;
            default:
                JOptionPane.showMessageDialog(this, "Invalid role!", "Error", JOptionPane.ERROR_MESSAGE);
        }

        return permissions;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            HomePage homePage = new HomePage("John Doe", "Patient");
            homePage.setVisible(true);
        });
    }
}
