import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginPage {
    public static void main(String[] args) {

        JFrame frame = new JFrame("AAIT Hospital Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 500);
        frame.setMinimumSize(new Dimension(800, 500));
        frame.setLayout(new CardLayout());

        JPanel loginPanel = createLoginPanel(frame);
        JPanel registrationPanel = createRegistrationPanel(frame);

        frame.add(loginPanel, "Login");
        frame.add(registrationPanel, "Register");

        CardLayout cl = (CardLayout) frame.getContentPane().getLayout();
        cl.show(frame.getContentPane(), "Login");

        frame.setVisible(true);
    }

    private static JPanel createLoginPanel(JFrame frame) {
        JPanel loginPanel = new JPanel();
        loginPanel.setBackground(new Color(240, 240, 255));
        loginPanel.setLayout(null);

        JLabel titleLabel = new JLabel("Login to your account");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setBounds(100, 20, 200, 30);
        loginPanel.add(titleLabel);

        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setBounds(50, 80, 100, 25);
        loginPanel.add(usernameLabel);

        JTextField usernameField = new JTextField();
        usernameField.setBounds(50, 110, 300, 30);
        loginPanel.add(usernameField);

        JLabel roleLabel = new JLabel("Role");
        roleLabel.setBounds(50, 150, 100, 25);
        loginPanel.add(roleLabel);

        JComboBox<String> roleComboBox = new JComboBox<>(new String[]{
                "Doctor", "Receptionist", "Patient", "Admin", "Pharmacist"
        });
        roleComboBox.setBounds(50, 180, 300, 30);
        loginPanel.add(roleComboBox);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(50, 220, 100, 25);
        loginPanel.add(passwordLabel);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(50, 250, 300, 30);
        loginPanel.add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.setBackground(new Color(100, 150, 255));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBounds(50, 300, 300, 40);
        loginPanel.add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                String role = (String) roleComboBox.getSelectedItem();

                if (username.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    try (Connection connection = DatabaseConfig.getConnection()) {

                        String query;

                        if ("Admin".equalsIgnoreCase(role)) {
                            query = "SELECT * FROM Admin WHERE username = ? AND password = ? AND role = ?";
                        } else if ("Patient".equalsIgnoreCase(role)) {
                            query = "SELECT * FROM Patients WHERE username = ? AND password = ? AND role = ?";
                        } else if ("Receptionist".equalsIgnoreCase(role)) {
                            query = "SELECT * FROM recertionistdata WHERE name = ? AND password = ? AND role = ?";
                        } else if ("Pharmacist".equalsIgnoreCase(role)) {
                            query = "SELECT * FROM pharmacist WHERE username = ? AND password = ? AND role = ?";
                        } else if ("Doctor".equalsIgnoreCase(role)) {
                            query = "SELECT * FROM doctors WHERE name = ? AND password = ? AND role = ?";
                        } else {

                            throw new IllegalArgumentException("Unknown role: " + role);
                        }

                        PreparedStatement preparedStatement = connection.prepareStatement(query);
                        preparedStatement.setString(1, username);
                        preparedStatement.setString(2, password);
                        preparedStatement.setString(3, role);
                        ResultSet resultSet = preparedStatement.executeQuery();

                        if (resultSet.next()) {
                            JOptionPane.showMessageDialog(frame, "Login successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                            frame.dispose();
                            HomePage homePage = new HomePage(username, role); // Pass username and role to HomePage
                            homePage.setVisible(true);
                        } else {
                            JOptionPane.showMessageDialog(frame, "Invalid credentials", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(frame, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });


        JLabel createAccountLabel = new JLabel("Don’t have an account? Create a new account");
        createAccountLabel.setForeground(new Color(255, 140, 0));
        createAccountLabel.setBounds(50, 350, 300, 25);
        loginPanel.add(createAccountLabel);

        createAccountLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        createAccountLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CardLayout cl = (CardLayout) frame.getContentPane().getLayout();
                cl.show(frame.getContentPane(), "Register");
            }
        });

        JLabel rightTitleLabel = new JLabel("About Our Hospital Management System");
        rightTitleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        rightTitleLabel.setBounds(400, 50, 350, 30);
        loginPanel.add(rightTitleLabel);

        JLabel descriptionLabel = new JLabel("\"An ounce of prevention is worth a pound of cure.\"");
        descriptionLabel.setBounds(400, 90, 350, 25);
        loginPanel.add(descriptionLabel);

        JButton createAccountButton = new JButton("Create a New Account");
        createAccountButton.setBounds(400, 130, 300, 40);
        createAccountButton.setBackground(new Color(255, 140, 0));
        createAccountButton.setForeground(Color.WHITE);
        loginPanel.add(createAccountButton);

        createAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout cl = (CardLayout) frame.getContentPane().getLayout();
                cl.show(frame.getContentPane(), "Register");
            }
        });

        return loginPanel;
    }

    private static JPanel createRegistrationPanel(JFrame frame) {
        JPanel registrationPanel = new JPanel();
        registrationPanel.setBackground(new Color(240, 240, 255));
        registrationPanel.setLayout(null);

        JLabel registrationTitle = new JLabel("Welcome to our Hospital Management System");
        registrationTitle.setFont(new Font("Arial", Font.BOLD, 18));
        registrationTitle.setBounds(100, 20, 500, 30);
        registrationPanel.add(registrationTitle);

        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setBounds(50, 80, 100, 25);
        registrationPanel.add(usernameLabel);

        JTextField usernameField = new JTextField();
        usernameField.setBounds(50, 110, 300, 30);
        registrationPanel.add(usernameField);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(50, 150, 100, 25);
        registrationPanel.add(passwordLabel);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(50, 180, 300, 30);
        registrationPanel.add(passwordField);

        JCheckBox patientCheckBox = new JCheckBox("I am a Patient");
        patientCheckBox.setBounds(50, 220, 300, 25);
        registrationPanel.add(patientCheckBox);

        JCheckBox termsCheckBox = new JCheckBox("I agree to the privacy policy and terms of service.");
        termsCheckBox.setBounds(50, 250, 300, 25);
        registrationPanel.add(termsCheckBox);

        JButton agreeAndJoinButton = new JButton("Agree and Join");
        agreeAndJoinButton.setBackground(new Color(100, 150, 255));
        agreeAndJoinButton.setForeground(Color.WHITE);
        agreeAndJoinButton.setBounds(50, 290, 300, 40);
        registrationPanel.add(agreeAndJoinButton);

        agreeAndJoinButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (username.isEmpty() || password.isEmpty() || !termsCheckBox.isSelected()) {
                    JOptionPane.showMessageDialog(frame, "Please fill in all fields and agree to the terms.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    try (Connection connection = DatabaseConfig.getConnection()) {
                        String query = "INSERT INTO Patients (username, password, role) VALUES (?, ?, ?)";
                        PreparedStatement preparedStatement = connection.prepareStatement(query);
                        preparedStatement.setString(1, username);
                        preparedStatement.setString(2, password);
                        preparedStatement.setString(3, patientCheckBox.isSelected() ? "Patient" : "User");

                        int rowsAffected = preparedStatement.executeUpdate();

                        if (rowsAffected > 0) {
                            JOptionPane.showMessageDialog(frame, "Registration successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                            CardLayout cl = (CardLayout) frame.getContentPane().getLayout();
                            cl.show(frame.getContentPane(), "Login");
                        } else {
                            JOptionPane.showMessageDialog(frame, "Registration failed. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(frame, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });

        JButton backButton = new JButton("Back");
        backButton.setBounds(50, 340, 300, 40);
        backButton.setBackground(new Color(255, 100, 100));
        backButton.setForeground(Color.WHITE);
        registrationPanel.add(backButton);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout cl = (CardLayout) frame.getContentPane().getLayout();
                cl.show(frame.getContentPane(), "Login");
            }
        });

        return registrationPanel;
    }
}
