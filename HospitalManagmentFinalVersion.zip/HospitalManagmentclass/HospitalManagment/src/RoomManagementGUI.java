import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class RoomManagementGUI extends JPanel {
    private JComboBox<String> roomIdComboBox, roomTypeComboBox;
    private JTextField patientIdField;
    private JCheckBox availabilityCheckbox;
    private JTextArea detailsArea;

    public RoomManagementGUI() {
        setLayout(null);

        JLabel lblRoomId = new JLabel("Room ID:");
        lblRoomId.setBounds(50, 50, 150, 30);
        add(lblRoomId);

        roomIdComboBox = new JComboBox<>(new String[]{"1", "2", "3", "4", "5", "6"});
        roomIdComboBox.setBounds(200, 50, 200, 30);
        add(roomIdComboBox);

        JLabel lblRoomType = new JLabel("Room Type:");
        lblRoomType.setBounds(50, 100, 150, 30);
        add(lblRoomType);

        roomTypeComboBox = new JComboBox<>(new String[]{"Single", "Double"});
        roomTypeComboBox.setBounds(200, 100, 200, 30);
        add(roomTypeComboBox);

        JLabel lblPatientId = new JLabel("Patient ID:");
        lblPatientId.setBounds(50, 150, 150, 30);
        add(lblPatientId);

        patientIdField = new JTextField();
        patientIdField.setBounds(200, 150, 200, 30);
        add(patientIdField);

        JLabel lblAvailability = new JLabel("Availability:");
        lblAvailability.setBounds(50, 200, 150, 30);
        add(lblAvailability);

        availabilityCheckbox = new JCheckBox();
        availabilityCheckbox.setBounds(200, 200, 50, 30);
        add(availabilityCheckbox);

        JButton assignRoomButton = createStyledButton("Assign Room", 50, 250);
        JButton freeRoomButton = createStyledButton("Free Room", 300, 250);
        JButton viewDetailsButton = createStyledButton("View Details", 550, 250);

        assignRoomButton.addActionListener(this::assignRoom);
        freeRoomButton.addActionListener(this::freeRoom);
        viewDetailsButton.addActionListener(this::viewRoomDetails);

        detailsArea = new JTextArea();
        detailsArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(detailsArea);
        scrollPane.setBounds(50, 320, 700, 120);
        add(scrollPane);
    }

    private JButton createStyledButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 200, 40);
        button.setBackground(new Color(0, 150, 200));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        add(button);
        return button;
    }

    private void assignRoom(ActionEvent e) {
        String roomId = (String) roomIdComboBox.getSelectedItem();
        String roomType = (String) roomTypeComboBox.getSelectedItem();
        String patientId = patientIdField.getText();
        boolean availability = !availabilityCheckbox.isSelected();

        if (patientId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Patient ID cannot be empty.");
            return;
        }

        String query = "INSERT INTO Rooms (roomID, roomType, patientID, availability) VALUES (?, ?, ?, ?) " +
                "ON DUPLICATE KEY UPDATE roomType = VALUES(roomType), patientID = VALUES(patientID), availability = VALUES(availability)";

        try (Connection conn = DatabaseConfig.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, roomId);
            stmt.setString(2, roomType);
            stmt.setString(3, patientId);
            stmt.setBoolean(4, availability);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Room information saved successfully!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error saving room information: you are using patient id which is not registered ");
        }
    }

    private void freeRoom(ActionEvent e) {
        String roomId = (String) roomIdComboBox.getSelectedItem();

        String query = "UPDATE Rooms SET patientID = NULL, availability = TRUE WHERE roomID = ?";

        try (Connection conn = DatabaseConfig.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, roomId);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Room freed successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Room is already available or does not exist.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error freeing room: " + ex.getMessage());
        }
    }

    private void viewRoomDetails(ActionEvent e) {
        String roomId = (String) roomIdComboBox.getSelectedItem();

        String query = "SELECT * FROM Rooms WHERE roomID = ?";

        try (Connection conn = DatabaseConfig.getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, roomId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    detailsArea.setText("Room ID: " + rs.getString("roomID") + "\n");
                    detailsArea.append("Room Type: " + rs.getString("roomType") + "\n");
                    detailsArea.append("Availability: " + (rs.getBoolean("availability") ? "Available" : "Occupied") + "\n");
                    detailsArea.append("Patient ID: " + (rs.getString("patientID") != null ? rs.getString("patientID") : "No patient assigned") + "\n");
                } else {
                    detailsArea.setText("No details found for Room ID: " + roomId);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error retrieving room details: " + ex.getMessage());
        }
    }
}
