import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class MedicalRecordGUI extends JPanel {
    private JTextField recordIDField, patientIDField, doctorIDField, diagnosisField, prescriptionField, treatmentDetailsField;
    private JButton addButton, viewButton, updateButton;
    private JTextArea outputArea;

    public MedicalRecordGUI() {
        setLayout(new BorderLayout());

        JPanel formPanel = createFormPanel();
        JPanel buttonPanel = createButtonPanel();
        JScrollPane outputScrollPane = createOutputArea();

        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        add(outputScrollPane, BorderLayout.EAST);
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        recordIDField = new JTextField();
        patientIDField = new JTextField();
        doctorIDField = new JTextField();
        diagnosisField = new JTextField();
        prescriptionField = new JTextField();
        treatmentDetailsField = new JTextField();

        formPanel.add(new JLabel("Record ID:"));
        formPanel.add(recordIDField);
        formPanel.add(new JLabel("Patient ID:"));
        formPanel.add(patientIDField);
        formPanel.add(new JLabel("Doctor ID:"));
        formPanel.add(doctorIDField);
        formPanel.add(new JLabel("Diagnosis:"));
        formPanel.add(diagnosisField);
        formPanel.add(new JLabel("Prescription:"));
        formPanel.add(prescriptionField);
        formPanel.add(new JLabel("Treatment Details:"));
        formPanel.add(treatmentDetailsField);

        return formPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));

        addButton = new JButton("Add Record");
        viewButton = new JButton("View Record");
        updateButton = new JButton("Update Record");

        addButton.setBackground(new Color(100, 150, 255));
        addButton.setForeground(Color.WHITE);
        viewButton.setBackground(new Color(255, 140, 0));
        viewButton.setForeground(Color.WHITE);
        updateButton.setBackground(new Color(100, 255, 100));
        updateButton.setForeground(Color.WHITE);

        addButton.addActionListener(e -> addRecord());
        viewButton.addActionListener(e -> viewRecord());
        updateButton.addActionListener(e -> updateRecord());

        buttonPanel.add(addButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(updateButton);

        return buttonPanel;
    }

    private JScrollPane createOutputArea() {
        outputArea = new JTextArea(15, 30);
        outputArea.setEditable(false);
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Record Details"));

        return scrollPane;
    }

    private void addRecord() {
        String recordID = recordIDField.getText();
        String patientID = patientIDField.getText();
        String doctorID = doctorIDField.getText();
        String diagnosis = diagnosisField.getText();
        String prescription = prescriptionField.getText();
        String treatmentDetails = treatmentDetailsField.getText();

        String query = "INSERT INTO MedicalRecords (recordID, patientID, doctorID, diagnosis, prescription, treatmentDetails) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, recordID);
            stmt.setString(2, patientID);
            stmt.setString(3, doctorID);
            stmt.setString(4, diagnosis);
            stmt.setString(5, prescription);
            stmt.setString(6, treatmentDetails);

            int rowsAffected = stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, rowsAffected > 0 ? "Record added successfully!" : "Failed to add record.");
            clearFields();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error adding record:you are trying to use unregistered patient or doctor id or you are using already used record id  " );
        }
    }

    private void viewRecord() {
        String recordID = recordIDField.getText();
        String query = "SELECT * FROM MedicalRecords WHERE recordID = ?";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, recordID);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                outputArea.setText("Record Details:\n");
                outputArea.append("Record ID: " + rs.getString("recordID") + "\n");
                outputArea.append("Patient ID: " + rs.getString("patientID") + "\n");
                outputArea.append("Doctor ID: " + rs.getString("doctorID") + "\n");
                outputArea.append("Diagnosis: " + rs.getString("diagnosis") + "\n");
                outputArea.append("Prescription: " + rs.getString("prescription") + "\n");
                outputArea.append("Treatment Details: " + rs.getString("treatmentDetails") + "\n");
            } else {
                JOptionPane.showMessageDialog(this, "No record found for Record ID: " + recordID);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error retrieving record: no record is saved by the id you are using" );
        }
    }

    private void updateRecord() {
        String recordID = recordIDField.getText();
        String treatmentDetails = treatmentDetailsField.getText();

        String query = "UPDATE MedicalRecords SET treatmentDetails = ? WHERE recordID = ?";

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, treatmentDetails);
            stmt.setString(2, recordID);

            int rowsAffected = stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, rowsAffected > 0 ? "Record updated successfully!" : "Failed to update record.");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error updating record:no information to be updated " );
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management", "root", "ayalk1995");
    }

    private void clearFields() {
        recordIDField.setText("");
        patientIDField.setText("");
        doctorIDField.setText("");
        diagnosisField.setText("");
        prescriptionField.setText("");
        treatmentDetailsField.setText("");
    }
}