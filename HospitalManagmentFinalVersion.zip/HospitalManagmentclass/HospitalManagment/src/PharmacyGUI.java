import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class PharmacyGUI extends JPanel {
    private JTextField txtPrescriptionId, txtPatientId, txtMedicationCost, txtServiceCharges, txtIssueDate;
    private JTextArea txtDetails;
    private JButton btnAdd, btnUpdate, btnIssue, btnView;

    public PharmacyGUI() {
        setLayout(new BorderLayout());


        JPanel mainPanel = createMainPanel();
        JPanel buttonPanel = createButtonPanel();

        add(mainPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private JPanel createMainPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(6, 2, 10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Add components
        mainPanel.add(new JLabel("Prescription ID:"));
        txtPrescriptionId = new JTextField();
        mainPanel.add(txtPrescriptionId);

        mainPanel.add(new JLabel("Patient ID:"));
        txtPatientId = new JTextField();
        mainPanel.add(txtPatientId);

        mainPanel.add(new JLabel("Medication Cost:"));
        txtMedicationCost = new JTextField();
        mainPanel.add(txtMedicationCost);

        mainPanel.add(new JLabel("Service Charges:"));
        txtServiceCharges = new JTextField();
        mainPanel.add(txtServiceCharges);

        mainPanel.add(new JLabel("Issue Date (YYYY-MM-DD):"));
        txtIssueDate = new JTextField();
        mainPanel.add(txtIssueDate);

        mainPanel.add(new JLabel("Details:"));
        txtDetails = new JTextArea(5, 20);
        txtDetails.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(txtDetails);
        mainPanel.add(scrollPane);

        return mainPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 4, 10, 10));

        // Buttons
        btnAdd = new JButton("Add Prescription");
        configureButton(btnAdd, new Color(100, 150, 255), e -> addPrescription());
        buttonPanel.add(btnAdd);

        btnUpdate = new JButton("Update Prescription");
        configureButton(btnUpdate, new Color(255, 140, 0), e -> updatePrescription());
        buttonPanel.add(btnUpdate);

        btnIssue = new JButton("Issue Prescription");
        configureButton(btnIssue, new Color(100, 255, 100), e -> issuePrescription());
        buttonPanel.add(btnIssue);

        btnView = new JButton("View Details");
        configureButton(btnView, new Color(255, 100, 100), e -> viewPrescription());
        buttonPanel.add(btnView);

        return buttonPanel;
    }

    private void configureButton(JButton button, Color color, java.awt.event.ActionListener listener) {
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.addActionListener(listener);
    }

    private void addPrescription() {
        String prescriptionId = txtPrescriptionId.getText();
        String patientId = txtPatientId.getText();
        String medicationCost = txtMedicationCost.getText();
        String serviceCharges = txtServiceCharges.getText();
        String issueDate = txtIssueDate.getText();

        if (prescriptionId.isEmpty() || patientId.isEmpty() || medicationCost.isEmpty() || serviceCharges.isEmpty() || issueDate.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!");
            return;
        }

        String query = "INSERT INTO pharmacyinfo (prescriptionID, patientID, medicationCost, serviceCharges, issueDate) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, Integer.parseInt(prescriptionId)); // Set prescription ID
            pstmt.setInt(2, Integer.parseInt(patientId)); // Set patient ID
            pstmt.setDouble(3, Double.parseDouble(medicationCost)); // Set medication cost
            pstmt.setDouble(4, Double.parseDouble(serviceCharges)); // Set service charges
            pstmt.setDate(5, Date.valueOf(issueDate)); // Set issue date (ensure valid format)

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Prescription added successfully!");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error adding prescription: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid number format: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "Invalid date format: " + e.getMessage());
        }
    }


    private void updatePrescription() {
        String prescriptionId = txtPrescriptionId.getText();
        String medicationCost = txtMedicationCost.getText();
        String serviceCharges = txtServiceCharges.getText();

        if (prescriptionId.isEmpty() || medicationCost.isEmpty() || serviceCharges.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!");
            return;
        }

        String query = "UPDATE pharmacyinfo SET medicationCost = ?, serviceCharges = ?, issueDate = ? WHERE prescriptionID = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            double medCost = Double.parseDouble(medicationCost);
            double svcCharges = Double.parseDouble(serviceCharges);
            double total = medCost + svcCharges;

            pstmt.setDouble(1, medCost);
            pstmt.setDouble(2, svcCharges);
            pstmt.setDouble(3, total);
            pstmt.setInt(4, Integer.parseInt(prescriptionId));

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(this, "Prescription updated successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Prescription ID not found!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error updating prescription: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid number format: " + e.getMessage());
        }
    }

    private void issuePrescription() {
        String prescriptionId = txtPrescriptionId.getText();
        String issueDate = txtIssueDate.getText();

        if (prescriptionId.isEmpty() || issueDate.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!");
            return;
        }

        String query = "UPDATE pharmacyinfo SET prescriptionStatus = 'ISSUED', issueDate = ? WHERE prescriptionID = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setDate(1, Date.valueOf(issueDate));
            pstmt.setInt(2, Integer.parseInt(prescriptionId));

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(this, "Prescription issued successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Prescription ID not found!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error issuing prescription: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "Invalid date format: " + e.getMessage());
        }
    }

    private void viewPrescription() {
        String prescriptionId = txtPrescriptionId.getText();

        if (prescriptionId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Prescription ID is required!");
            return;
        }

        String query = "SELECT * FROM pharmacyinfo WHERE prescriptionID = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, Integer.parseInt(prescriptionId));

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    txtDetails.setText(
                            "Prescription ID: " + rs.getInt("prescriptionID") +
                                    "\nPatient ID: " + rs.getInt("patientID") +
                                    "\nMedication Cost: $" + rs.getDouble("medicationCost") +
                                    "\nService Charges: $" + rs.getDouble("serviceCharges") +
//                                    "\nTotal Amount: $" + rs.getDouble("totalAmount") +
                                    "\nPrescription Status: " + rs.getString("prescriptionStatus") +
                                    "\nIssue Date: " + rs.getDate("issueDate")
                    );
                } else {
                    JOptionPane.showMessageDialog(this, "Prescription ID not found!");
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error retrieving prescription: " + e.getMessage());
        }
    }
}