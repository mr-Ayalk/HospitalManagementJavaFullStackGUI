import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class DoctorPrescriptionGUI extends JPanel {
    private JTable tablePatients;
    private JTextArea txtPrescription, txtSchedule;
    private JTextField txtDoctorID;
    private JButton btnSubmit, btnFilter;
    private DefaultTableModel tableModel;

    public DoctorPrescriptionGUI() {
        setLayout(new BorderLayout());

        JPanel doctorIDPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        doctorIDPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JLabel lblDoctorID = new JLabel("Doctor ID:");
        txtDoctorID = new JTextField(10);
        btnFilter = new JButton("Filter Patients");
        doctorIDPanel.add(lblDoctorID);
        doctorIDPanel.add(txtDoctorID);
        doctorIDPanel.add(btnFilter);

        String[] columnNames = {"Patient ID", "Name", "Medical History"};
        tableModel = new DefaultTableModel(columnNames, 0);
        tablePatients = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(tablePatients);

        txtPrescription = new JTextArea(5, 20);
        txtSchedule = new JTextArea(3, 20);
        txtPrescription.setBorder(BorderFactory.createTitledBorder("Prescription"));
        txtSchedule.setBorder(BorderFactory.createTitledBorder("Schedule"));

        btnSubmit = new JButton("Submit Prescription");
        btnSubmit.addActionListener(e -> submitPrescription());

        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        inputPanel.add(new JScrollPane(txtPrescription), BorderLayout.NORTH);
        inputPanel.add(new JScrollPane(txtSchedule), BorderLayout.CENTER);
        inputPanel.add(btnSubmit, BorderLayout.SOUTH);

        add(doctorIDPanel, BorderLayout.NORTH);
        add(tableScrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.SOUTH);

        btnFilter.addActionListener(e -> loadPatients());
    }

    private void loadPatients() {
        tableModel.setRowCount(0);
        String doctorID = txtDoctorID.getText().trim();

        if (doctorID.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Doctor ID to filter patients!");
            return;
        }

        try (Connection conn = DatabaseConfig.getConnection()) {
            String query = "SELECT p.patientID, p.name, p.medicalHistory " +
                    "FROM patientinformation p " +
                    "INNER JOIN appointments a ON p.patientID = a.patientID " +
                    "WHERE a.doctorID = ?";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, doctorID);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        int patientID = rs.getInt("patientID");
                        String name = rs.getString("name");
                        String medicalHistory = rs.getString("medicalHistory");

                        tableModel.addRow(new Object[]{patientID, name, medicalHistory});
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading patients: " + e.getMessage());
        }
    }

    private void submitPrescription() {
        int selectedRow = tablePatients.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a patient!");
            return;
        }

        int patientID = (int) tableModel.getValueAt(selectedRow, 0);
        String prescriptionDetails = txtPrescription.getText().trim();
        String treatmentSchedule = txtSchedule.getText().trim();
        String doctorID = txtDoctorID.getText().trim();

        if (prescriptionDetails.isEmpty() || treatmentSchedule.isEmpty() || doctorID.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!");
            return;
        }

        try (Connection conn = DatabaseConfig.getConnection()) {
            String query = "INSERT INTO DoctorPrescriptions (patientID, doctorID, prescriptionDetails, treatmentSchedule) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setInt(1, patientID);
                pstmt.setInt(2, Integer.parseInt(doctorID));
                pstmt.setString(3, prescriptionDetails);
                pstmt.setString(4, treatmentSchedule);

                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Prescription submitted successfully!");

                txtPrescription.setText("");
                txtSchedule.setText("");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error submitting prescription: " + e.getMessage());
        }
    }
}
